  <!-- /.navbar-default -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('img/logotipo.png')); ?>" title="QuetzalEdu"></a>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="<?php echo e(url('/')); ?>">¿QUIÉNES SOMOS?</a></li>
            <li><a href="#cursos">CURSOS</a></li>
            <li><a href="<?php echo e(url('contacto')); ?>">EXPERIENCIAS</a></li>
            <li><a href="<?php echo e(url('/')); ?>">CONTACTO</a></li>
            <li><a href="<?php echo e(url('/ingresar')); ?>" class="ingresar">INICIAR SESIÓN</a></li>
            <a href="<?php echo e(url('/registro')); ?>" class="btn btn-danger registro">REGISTRARSE</a>
          </ul>
        </div>
      </div>
    </nav>
  <!-- navbar-default./ -->