<!DOCTYPE html>
<html lang="es" ng-app="MyFirstApp">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0" />
		<title>
			QuetzalEdu - <?php echo $__env->yieldContent('title', 'Default'); ?> 
		</title>
		<link rel="icon" href="<?php echo e(asset('img/favicon.png')); ?>"/>
	    <link rel="stylesheet" href="<?php echo e(asset('bootstrap-3.3.7/css/bootstrap.min.css')); ?>"/>
	    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>"/>
	    <link rel="stylesheet" href="<?php echo e(asset('font-awesome-4.7.0/css/font-awesome.min.css')); ?>"/>
	</head>
	<body ng-controller="FirstController">
		<?php echo $__env->make('index.template.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldContent('section'); ?>
		<script src="<?php echo e(asset('jquery-3.1.1/jquery-3.1.1.min.js')); ?>"></script>
	    <script src="<?php echo e(asset('bootstrap-3.3.7/js/bootstrap.min.js')); ?>"></script>
	    <script src="<?php echo e(asset('angularjs/angular.min.js')); ?>"></script>
	    <script src="<?php echo e(asset('js/HolaController.js')); ?>"></script>
	    <script>
			$('div.alert').not('.alert-important').delay(4000).fadeOut(350);
		</script>
		<!-- livezilla.net code --><script type="text/javascript" id="7d00d1a6ace747e1ffac6af0bed7c229" src="http://localhost/livez/livezilla/script.php?id=7d00d1a6ace747e1ffac6af0bed7c229"></script><!-- http://www.livezilla.net -->
	</body>
</html>