<?php $__env->startSection('title'); ?>

Contacto

<?php $__env->stopSection(); ?>

Formulario de Contacto
<?php echo $__env->make('index.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>