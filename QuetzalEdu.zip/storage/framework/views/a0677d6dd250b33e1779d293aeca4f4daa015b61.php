<?php $__env->startSection('title'); ?>

Registro

<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>

  <div class="col-md-5 center-block quitarfloat">
    <div>
    <?php if(Session::has('message-error')): ?>
      <div class="alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <center><span class="glyphicon glyphicon-lock"></span> &nbsp;<?php echo e(Session::get('message-error')); ?></center>
      </div>
    <?php endif; ?>
    <hr>
    <?php echo Form::open(['route'=>'users.store', 'method'=>'POST']); ?>

    <div class="form-group">
      <label>Nombre de usuario</label>
      <input type="text" name="name" class="in form-control" placeholder="Nombre de usuario" required>
        <?php if($errors->has('name')): ?>
          <span class="error">* <?php echo e($errors->first('name')); ?></span>
        <?php endif; ?>
    </div>
    <div class="form-group">
      <label>Correo electrónico</label>
      <input type="email" name="email" class="in form-control" placeholder="Correo electrónico" required">
        <?php if($errors->has('email')): ?>
          <span class="error">* <?php echo e($errors->first('email')); ?></span>
        <?php endif; ?>
    </div>
    <div class="form-group">
      <label>Contraseña</label>
      <input type="password" name="password" class="form-control" placeholder="Contraseña" required >
        <?php if($errors->has('password')): ?>
          <span class="error">* <?php echo e($errors->first('password')); ?></span>
        <?php endif; ?>
    </div>
    <div class="form-group">
      <label>Confirmar contraseña</label>
      <input type="password" name="mypassword" class="form-control" placeholder="Confirmar contraseña" required >
        <?php if($errors->has('mypassword')): ?>
          <span class="error">* <?php echo e($errors->first('mypassword')); ?></span>
        <?php endif; ?>
    </div>
    <div class="form-group">
      <input type="checkbox" name="" checked><span> Aceptar términos y condiciones</span>
    </div>
    <div class="form-group">
      <a href="<?php echo e(url('/')); ?>" class="btn btn-danger"><span class="glyphicon glyphicon-remove"></span> Cancelar</a>
      <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-ok"></span> Registrarse</button>
    </div>
    <?php echo Form::close(); ?>

    </div>
  </div>

<?php $__env->stopSection(); ?>

   
<?php echo $__env->make('index.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>