<?php $__env->startSection('title','Iniciar Sesión'); ?>

<?php $__env->startSection('section'); ?>
        <br>
        <div class="col-md-5 center-block quitarfloat" style="font-weight: bold;">
          <div>
            <center>
              <h3>
                <span class="label label-warning">
                  !Iniciar Sesión!
                </span>
              </h3>
            </center>
            <hr>
            <?php if(Session::has('message-error')): ?>
              <div class="alert alert-danger alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
                <center>
                  <span class="glyphicon glyphicon-lock"></span> 
                  <?php echo e(Session::get('message-error')); ?>

                </center>
              </div>
            <?php endif; ?>
            <?php echo Form::open(['route'=>'log', 'method'=>'POST']); ?>

              <div class="form-group has-feedback">
                <input type="email" name="email" class="form-control" placeholder="Correo electrónico" required autofocus />
                <span class="fa fa-user fa-lg form-control-feedback"></span> 
                <?php if($errors->has('email')): ?>
                  <span class="error" >* <?php echo e($errors->first('email')); ?></span>
                <?php endif; ?>
              </div>
              <div class="form-group has-feedback">
                <input type="password" name="password" class="form-control" placeholder="Contraseña" required />
                <span class="fa fa-lock fa-lg form-control-feedback"></span> 
                <?php if($errors->has('password')): ?>
                  <span class="error">* <?php echo e($errors->first('password')); ?></span>
                <?php endif; ?>
              </div>
              <div class="form-group">
                <input type="checkbox" name="" checked><span>Recordar mi contraseña</span>
              </div>
              <div class="form-group">
                <button type="submit" class="btn btn-success btn-block"> INGRESAR</button>
                <div class="contra">
                <p><span class="pull-left"> ¿No tienes <a href="<?php echo e(url('/registro')); ?>" style="text-decoration: underline;"> Cuenta?</a></span></p> ¿Olvidaste tu <a href="" style="text-decoration: underline;">Contraseña?</a>
                </div>
              </div> 
              <hr>
              <div class="form-group">
                <a class="btn btn-primary btn-block" href="<?php echo e(route('facebook.login')); ?>" style="background-color: #3b5998;">
              Iniciar con &nbsp;<img src="img/facebook.png">
                </a>
              </div>
              <?php echo Form::close(); ?>

          </div>
        </div>
<?php $__env->stopSection(); ?>

   
<?php echo $__env->make('index.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>