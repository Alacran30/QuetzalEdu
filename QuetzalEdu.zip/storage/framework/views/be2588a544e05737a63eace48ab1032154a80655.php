<?php $__env->startSection('title'); ?>

Plataforma Web

<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>
  <!-- /.carousel-slide -->
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <div class="carousel-inner">
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
            <li data-target="#myCarousel" data-slide-to="3"></li>
        </ol>
        <div class="item active">
          <center>
            <img class="img-responsive" src="<?php echo e(asset('img/slide1.png')); ?>">
          </center> 
        </div>
        <div class="item">
          <center>
            <img class="img-responsive" src="<?php echo e(asset('img/slide2.png')); ?>">
          </center> 
        </div>
        <div class="item">
          <center>
            <img class="img-responsive" src="<?php echo e(asset('img/slide3.png')); ?>">
          </center> 
        </div>
        <div class="item">
          <center>
            <img class="img-responsive" src="<?php echo e(asset('img/slide4.png')); ?>">
          </center> 
        </div>
      </div>
    </div>
  <!-- /.carousel-slide -->
    <div class="repeat">
    </div>
    <div class="container">
      <center>
      <h3>¿En qué desea capacitarse?</h3>
      </center>
    </div> 
    <hr>
<?php $__env->stopSection(); ?>

   
<?php echo $__env->make('index.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>