<?php $__env->startSection('title'); ?>

Perfil

<?php $__env->stopSection(); ?>


<?php $__env->startSection('section'); ?>
	
	  <br>
<br>

<div class="row">
  <div class="col-lg-3">
    <center>
    <img style="width: 235px; height: 235px;margin-right: 10px;margin-top: -10px;border: solid 5px #c1d188;" src="<?php echo e(asset('img/avatar.png')); ?>">
        <h5>Imagen de perfil <span class="fa fa-edit"></span></h5>
    <br>
    <img src="<?php echo e(asset('img/logo_quetzal.png')); ?>">
    </center>
  </div>




  <div class="col-lg-6" style="margin-top: -30px;">

<hr>
 <ul class="nav nav-tabs">
                  <li class="active"><a href="#info-tab" data-toggle="tab">Datos Personales <i class="fa"></i></a></li>
                  <li><a href="#adress-tab" data-toggle="tab">Dirección <i class="fa"></i></a></li>
                  <li><a href="#profesional-tab" data-toggle="tab">Información Profesional <i class="fa"></i></a></li>
              </ul>
              <br>
  <div class="tab-content">
    <div class="tab-pane active" id="info-tab">


   
  <label>Nombre(s) *</label>
  <input type="text" name="nombre" class="form-control">

  <label>Apellido Paterno *</label>
  <input type="text" name="paterno" class="form-control">

  <label>Apellido Materno *</label>
  <input type="text" name="materno" class="form-control">

  <label>Género *</label>
  <input type="text" name="genero" class="form-control">

  <label>Fecha de Nacimiento *</label>
  <input type="date" name="nacimiento" class="form-control">

  <label>Teléfono Oficina</label>
  <input type="text" name="oficina" class="form-control">

  <label>Teléfono Móvil</label>
  <input type="text" name="movil" class="form-control">

  </div>

  <div class="tab-pane" id="adress-tab">
     <label>Calle *</label>
  <input type="text" name="calle" class="form-control">

     <label>Número Interior *</label>
  <input type="text" name="interior" class="form-control">
  
     <label>Número Exterior *</label>
  <input type="text" name="exterior" class="form-control">

      <label>Colonia *</label>
  <input type="text" name="colonia" class="form-control">
  
     <label>Municipio *</label>
  <input type="text" name="municipio" class="form-control">

      <label>Estado *</label>
  <input type="text" name="estado" class="form-control">

      <label>Código Postal *</label>
  <input type="text" name="postal" class="form-control">

  </div>


   <div class="tab-pane" id="profesional-tab">
      <label>Nivel de Estudios *</label>
  <input type="text" name="estudios" class="form-control">
      <label>Especialidad *</label>
  <input type="text" name="especialidad" class="form-control">
      <label>Resumen Curricular</label>
      <textarea class="form-control"></textarea>
   </div>


  
     




  </div>

  <br>
  <a class="btn btn-danger" href=""> Cancelar</a>

  <input type="submit" value="Guardar" class="btn btn-success">
  
  <!--<div style="border: solid 2px #c1d188;margin-top: -5px;padding: 10px;padding-top: 0px;">
  <div class="col-lg-6">
    <a class="btn btn-success btn-block" style="background-color:#7fa57b;"> Mensajes </a>
  </div>
  <div class="col-lg-6">
    <a class="btn btn-warning btn-block" style="background-color:#c1d188;"> Asignar Actividad </a>
  </div>
  <hr>
  <textarea class="form-control" placeholder="Escriba su mensaje aquí..."></textarea>
  <hr>
  <i class="fa fa-book fa-2x" style="padding: 4px;"></i>&nbsp;
  <i class="fa fa-clipboard fa-2x" style="padding: 4px;"></i>&nbsp;
  <i class="fa fa-chain fa-2x" style="padding: 4px;"></i>&nbsp;
  <a class="btn btn-warning">Cancelar</a> <a class="btn btn-success" >Enviar</a>
  <br>
  <br>
  </div>
  <div style="border: solid 2px #7fa57b;margin-top: -5px;padding: 10px;padding-top: 0px;margin-top: 10px;">
    <h5 style="color:#7fa57b">Publicaciones</h5>
    <hr>
    <h6 style="color:#7fa57b">Sé el primero en publicar...Comienza la Conversación</h6>
  </div>-->
  </div>



  <div class="col-lg-3">
  <center>
    <h5 style="border: solid 5px #c1d188;padding: 5px;margin-right: 20px;color:#7fa57b;margin-top: -5px;">GESTIÓN DE GRUPOS</h5>

    <h5 style="border: solid 5px #c1d188;background-color:#c1d188;padding: 5px;margin-right: 20px;margin-top: -5px;color: #fff;">ADMINISTRAR GRUPOS</h5>

    <h5 style="border: solid 5px #c1d188;background-color:#c1d188;padding: 5px;margin-right: 20px;margin-top: -5px;color: #fff;">CREAR GRUPO</h5>

    <h5 style="border: solid 5px #c1d188;background-color:#c1d188;padding: 5px;margin-right: 20px;margin-top: -5px;color: #fff;">UNIRSE A UN GRUPO</h5>

    <h5 style="border: solid 5px #c1d188;padding: 5px;color:#7fa57b;margin-right: 20px;margin-top: -5px;">MIS GRUPOS</h5>

    <h6 style="border: solid 5px #7fa57b;background-color:#7fa57b;padding: 5px;margin-right: 20px;margin-top: -5px;color: #fff;">Competencias Docentes</h6>
    <h6 style="border: solid 5px #7fa57b;background-color:#7fa57b;padding: 5px;margin-right: 20px;margin-top: -5px;color: #fff;">Estrategias Docentes</h6>
    <h6 style="border: solid 5px #7fa57b;background-color:#7fa57b;padding: 5px;margin-right: 20px;margin-top: -5px;color: #fff;">Planeación y Desarrollo</h6>
    <h6 style="border: solid 5px #7fa57b;background-color:#7fa57b;padding: 5px;margin-right: 20px;margin-top: -5px;color: #fff;">Exámenes de Oposición</h6>
    </center>
  </div>
</div>

<div class="row" style="background-color:#c1d188;color: #fff;font-weight: bold;margin-top: 30px;">
  <center>
  <div class="col-lg-4">AVISO DE PRIVACIDAD</div>
  <div class="col-lg-4">TÉRMINOS Y CONDICIONES</div>
  <div class="col-lg-4">CONTÁCTANOS</div>
  </center>
</div>

<div class="repeat" style="border-top: solid 5px #dfdfdf;">
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('instructor.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>