<?php $__env->startSection('title'); ?>

Iniciar Sesión

<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>

 <hr>

  <div class="col-md-5 center-block quitarfloat">
    <div>
      <?php if(Session::has('message-error')): ?>
        <div class="alert alert-warning alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
          <center><?php echo e(Session::get('message-error')); ?></center>
        </div>
      <?php endif; ?>
      <hr>
      <?php echo Form::open(['route'=>'login', 'method'=>'POST']); ?>

        <div class="form-group has-feedback">
          <input type="emil" name="email" class="form-control" placeholder="Correo electrónico / Usuario" required/>
          <span class="fa fa-user fa-lg form-control-feedback"></span> 
          <?php if($errors->has('email')): ?>
            <span class="error" >* <?php echo e($errors->first('email')); ?></span>
          <?php endif; ?>
        </div>
          <div class="form-group has-feedback">
          <input type="password" name="password" class="form-control" placeholder="Contraseña" required />
          <span class="fa fa-lock fa-lg form-control-feedback"></span> 
          <?php if($errors->has('password')): ?>
            <span class="error">* <?php echo e($errors->first('password')); ?></span>
          <?php endif; ?>
        </div>
        <div class="form-group">
          <input type="checkbox" name="" checked><span> Recordar mi contraseña</span>
        </div>
        <div class="form-group">
          <button type="submit" class="btn btn-success btn-block"> ENTRAR</button>
        </div>
      <?php echo Form::close(); ?>

    </div>
    <div class="contra">
      <p><span class="pull-left cuenta">¿No tienes cuenta?</span></p> ¿Olvidaste tu <a href="">Contraseña?</a>
    </div>
    <div>
      <a href="<?php echo e(url('/registro')); ?>" class="btn btn-danger pull-left">Regístrate</a>
    </div>
  </div>
  </div>

<?php $__env->stopSection(); ?>

   
<?php echo $__env->make('index.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>