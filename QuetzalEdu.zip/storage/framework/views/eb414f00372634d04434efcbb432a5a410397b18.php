<?php $__env->startSection('title'); ?>

Inicio

<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>

<br>

<div class="container">

<div class="row">
  <div class="col-md-12">
    <h3>
      <i class="fa fa-user-plus"></i>
      Editar Instructor
    </h3>
  </div>
</div>

<hr>


<?php echo Form::open(['route' => ['users.update', $user], 'method' => 'PUT']); ?>


<div class="form-group">
  
  <div class="form-group">
    <?php echo Form::label('username', 'Username:'); ?>

    <?php echo Form::text('username', $user->username, ['class' => 'form-control', 'placeholder' => 'Nombre completo', 'required']); ?>

  </div>

    <?php echo Form::label('email', 'Correo Electrónico:'); ?>

    <?php echo Form::email('email', $user->email, ['class' => 'form-control', 'placeholder' => 'Correo Electrónico', 'required']); ?>


    <?php echo Form::label('nombre', 'Nombre:'); ?>

    <?php echo Form::text('nombre', $user->persona->nombre, ['class' => 'form-control', 'placeholder' => 'Nombre completo', 'required']); ?>


    <?php echo Form::label('paterno', 'Apellido Paterno:'); ?>

    <?php echo Form::text('paterno', $user->persona->paterno, ['class' => 'form-control', 'placeholder' => 'Nombre completo', 'required']); ?>


    <?php echo Form::label('materno', 'Apellido Materno:'); ?>

    <?php echo Form::text('materno', $user->persona->materno, ['class' => 'form-control', 'placeholder' => 'Nombre completo', 'required']); ?>


  <br>

  <a href="<?php echo e(route('users.index')); ?>" class="btn btn-danger">Cancelar</a>
  <input type="submit" value="Editar" class="btn btn-success">

</div>

<?php echo Form::close(); ?>



</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>