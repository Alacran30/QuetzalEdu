<?php $__env->startSection('title'); ?>

Agregar Area de Conocimiento

<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>

<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<br>

<div class="container">

<div class="row">
  <div class="col-md-12">
    <h3>
      <i class="fa fa-plus"></i>
      Agregar Area de Conocimiento
    </h3>
  </div>
</div>

<hr>
            
            <?php if(Session::has('message-error')): ?>
              <div class="alert alert-danger alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
                <center>
                <span class="glyphicon glyphicon-lock"></span> 
                  <?php echo e(Session::get('message-error')); ?>

                </center>
              </div>
            <?php endif; ?>


<?php echo Form::open(['route' => 'areas_conocimiento.store', 'method' => 'POST']); ?>


<div class="form-group">
  
  <label>Nombre:</label>
  <input type="text" name="area_conocimiento" class="form-control" placeholder="Nombre del Area de Conocimiento" required>

  <br>

  <a href="<?php echo e(route('areas_conocimiento.index')); ?>" class="btn btn-danger">Cancelar</a>
  <input type="submit" value="Agregar" class="btn btn-success">

</div>

<?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>