<?php $__env->startSection('title'); ?>

Agregar Competencia Docente

<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>

<br>
<div class="container">
<div class="row">
  <div class="col-md-12">
    <h4>
      <i class="fa fa-plus"></i>
      Agregar Competencia Docente
    </h4>
  </div>
</div>
<hr>
<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger" role="alert">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
      </ul>
    </div>
<?php endif; ?>
<div class="panel panel-primary">
		<div class="panel-heading">
			<h6 style="color: #fff;"><i class="fa fa-check-circle-o ic">&nbsp;</i> D a t o s </h6>
		</div>
		<div class="panel-body">
<?php echo Form::open(['route' => 'competencia.store', 'method' => 'POST', 'files' => 'true']); ?>


<?php echo e(csrf_field()); ?>


<div class="form-group">
	<?php echo Form::label('titulo', 'Titulo de Competencia'); ?>

	<?php echo Form::text('titulo',null, ['class' => 'form-control', 'placeholder' => 'Titulo de Competencia', 
	'required', 'autofocus']); ?>

</div>

<div class="form-group">
	<?php echo Form::label('area_id', 'Área de Conocimiento'); ?>

	<?php echo Form::select('area_id', $areas , null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
	<?php echo Form::label('descripcion', 'Descripción General del Curso'); ?>

	<?php echo Form::textarea('descripcion',null, ['class' => 'form-control','placeholder' => 'Descripción General del Curso', 'required']); ?>

</div>

<div class="form-group">
	<i class="fa fa-file"></i> <?php echo Form::label('informacion', 'Información General del Curso'); ?> 
	<input id="informacion" type="file" name="informacion" class="file-loading" required>
</div>

<div class="form-group">
	<i class="fa fa-youtube-play"></i> <?php echo Form::label('video', 'Video General del Curso'); ?> 
	<input id="video" type="file" name="video" class="file-loading" required>
</div>

<div class="form-group">
	<i class="fa fa-file-pdf-o"></i> <?php echo Form::label('contenidos', 'Actividades del Curso'); ?> 
	<input id="actividades" multiple="" name="actividades[]" type="file" class="file-loading" required>
</div>

<div class="form-group">
  <i class="fa fa-suitcase"></i> <?php echo Form::label('mochila', 'Mochila del Curso'); ?> 
  <input id="mochila" multiple="" name="mochila[]" type="file" class="file-loading" required>
</div>

<div class="form-group">
    <a href="<?php echo e(route('competencia.index')); ?>" class="btn btn-danger"> Cancelar</a>
	<input type="submit" value="Crear Curso" class="btn btn-success">
</div>

<?php echo Form::close(); ?>


</div>


</div>

<div class="well" style="border-radius: 5px;border: solid 2px #dfdfdf;">
      <div class="row">
        <center>
          <div class="col-md-6">
            <span class="glyphicon glyphicon-globe"></span>&nbsp; Plataforma de Capacitación Docente :: QuetzalEdu
          </div>
          <div class="col-md-6">
            <span class="glyphicon glyphicon-copyright-mark"></span>&nbsp;&nbsp;2017 SICIPAED S. de R.L. de C.V.
          </div>
        </center>
      </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>