	$('div.alert').not('.alert-important').delay(4000).fadeOut(350);

	$(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip();
    });
		